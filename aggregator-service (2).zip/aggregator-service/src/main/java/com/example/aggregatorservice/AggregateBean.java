package com.example.aggregatorservice;

import java.util.List;

public class AggregateBean {
	
	private List<Orders> orders;
	private Users user;
	
	public AggregateBean(List<Orders> orders, Users user) {
		super();
		this.orders = orders;
		this.user = user;
	}
	
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "AggregateBean [orders=" + orders + ", user=" + user + "]";
	}

	
}
