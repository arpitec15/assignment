package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.dao.Orders;
import com.example.model.*;


public interface OrderRepository extends JpaRepository<Orders, Integer> {
	
	Optional<Orders> findById(Integer id);
}
