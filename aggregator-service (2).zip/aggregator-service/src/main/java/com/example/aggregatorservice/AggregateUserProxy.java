package com.example.aggregatorservice;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name="user-service", url="localhost:8080/users")
public interface AggregateUserProxy {

	
	@GetMapping(value = "/{id}")
    public Users retrieveUser(@PathVariable int id);
}


