package com.example.aggregatorservice;

import com.example.aggregatorservice.AggregateProxy;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@Autowired
	private AggregateProxy proxy;
	
	@Autowired
	private AggregateUserProxy user_proxy;
	
	@GetMapping("/orderdetails/{user_id}")
	public AggregateBean getFullDetail (@PathVariable Integer user_id) {
		
		List<Orders> OrdersResponse = proxy.retrieveOrder(user_id);
		Users UsersResponse = user_proxy.retrieveUser(user_id);
//		System.out.println(response);
		
		
//		Users user = new Users(1,"Arpit",27, "arpitec@gmail.com");
		return new AggregateBean(OrdersResponse, UsersResponse);
//		return new AggregateBean(null, null);
				
		
	}

}
