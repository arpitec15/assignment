package com.example.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/orders")
public class OrderResource {
	
	@Autowired
	private OrderDAOService service;
	
	@GetMapping("/{userId}")
	public List<Orders> retrieveOrder(@PathVariable Integer userId) {	
		System.out.println("DEBUG ******** Retrieving order");
		return service.findOrders(userId);
	}
	
	@GetMapping("/all")
	public List<Orders> retrieveAll(){
		
		System.out.println("DEBUG ******** Retrieving all orders");
		return service.findAll();
	}

}
