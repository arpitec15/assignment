package com.example.aggregatorservice;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name="order-service", url="localhost:8081/orders")
public interface AggregateProxy {

	@GetMapping("/{userId}")
	public List<Orders> retrieveOrder(@PathVariable("userId") Integer userId);
}


